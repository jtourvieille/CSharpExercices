﻿using System;

namespace Exam.Impl
{
    public class FizzBuzzService
    {
        public string Play(int upperBound)
        {
            throw new NotImplementedException();
        }
    }
}
