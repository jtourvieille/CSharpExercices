﻿using System;

namespace Exam.Impl
{
    public class Armstrong
    {
        public bool IsArmstrong(int input)
        {
            throw new NotImplementedException();
        }
    }
}
